import string

ALPH = string.ascii_uppercase
A2I = {c: i for i, c in enumerate(ALPH)}
I2A = {i: c for i, c in enumerate(ALPH)}

# Historical rotor wirings (Enigma I)
ROTOR_WIRINGS = {
    "I":   ("EKMFLGDQVZNTOWYHXUSPAIBRCJ", "Q"),
    "II":  ("AJDKSIRUXBLHWTMCQGZNPYFVOE", "E"),
    "III": ("BDFHJLCPRTXVZNYEIWGAKMUSQO", "V"),
    "IV":  ("ESOVPZJAYQUIRHXLNFTGKDCMWB", "J"),
    "V":   ("VZBRGITYUPSDNHLXAWMJQOFECK", "Z"),
}
REFLECTORS = {
    "B": "YRUHQSLDPXNGOKMIEBFZCWVJAT",
    "C": "FVPJIAOYEDRZXWGCTKUQSBNMHL",
}

def shift(c, n):
    return I2A[(A2I[c] + n) % 26]

def unshift(c, n):
    return I2A[(A2I[c] - n) % 26]

class Rotor:
    def __init__(self, name, pos="A", ring=1):
        wiring, notch = ROTOR_WIRINGS[name]
        self.name = name
        self.wiring = wiring
        self.notch = notch
        self.pos = pos  # 'A'..'Z'
        self.ring = ring  # 1..26 (1 means 'A')
        # Precompute inverse wiring
        inv = [''] * 26
        for i, c in enumerate(wiring):
            inv[A2I[c]] = I2A[i]
        self.inv_wiring = ''.join(inv)

    def at_notch(self):
        return self.pos == self.notch

    def step(self):
        self.pos = shift(self.pos, 1)

    def forward(self, c):
        # Apply position and ring offset
        offset = (A2I[self.pos] - (self.ring - 1)) % 26
        c1 = shift(c, offset)
        c2 = self.wiring[A2I[c1]]
        return unshift(c2, offset)

    def backward(self, c):
        offset = (A2I[self.pos] - (self.ring - 1)) % 26
        c1 = shift(c, offset)
        c2 = self.inv_wiring[A2I[c1]]
        return unshift(c2, offset)

class Plugboard:
    def __init__(self, pairs=None):
        self.map = {c: c for c in ALPH}
        pairs = pairs or []
        for a, b in pairs:
            self.map[a], self.map[b] = b, a

    def swap(self, c):
        return self.map[c]

class Enigma:
    def __init__(self, rotor_names=("I","II","III"), reflector="B",
                 positions="AAA", rings=(1,1,1), plug_pairs=None):
        # rotors are stored left->right, but signal goes right->left first
        self.rotors = [
            Rotor(rotor_names[0], positions[0], rings[0]),
            Rotor(rotor_names[1], positions[1], rings[1]),
            Rotor(rotor_names[2], positions[2], rings[2]),
        ]
        self.reflector = REFLECTORS[reflector]
        self.plugboard = Plugboard(plug_pairs)

    def _reflect(self, c):
        return self.reflector[A2I[c]]

    def step_rotors(self):
        # Simplified stepping with the classic middle-rotor double-step behavior
        left, mid, right = self.rotors
        if mid.at_notch():      # double-step condition
            left.step()
            mid.step()
        if right.at_notch():    # causes mid to step
            mid.step()
        right.step()

    def enc_char(self, c):
        if c not in ALPH:
            return c
        self.step_rotors()

        c = self.plugboard.swap(c)

        # Right -> Left through rotors (signal path)
        for r in reversed(self.rotors):
            c = r.forward(c)

        c = self._reflect(c)

        # Left -> Right back through rotors
        for r in self.rotors:
            c = r.backward(c)

        c = self.plugboard.swap(c)
        return c

    def enc(self, text):
        out = []
        for ch in text.upper():
            if ch in ALPH:
                out.append(self.enc_char(ch))
        return ''.join(out)

if __name__ == "__main__":
    # Example settings
    plug = [("A","V"), ("B","S"), ("C","G"), ("D","L"), ("F","U"),
            ("H","Z"), ("I","N"), ("K","M"), ("O","W"), ("R","X")]

    e = Enigma(rotor_names=("I","II","III"), reflector="B",
               positions="AAA", rings=(1,1,1), plug_pairs=plug)

    pt = "HELLOWORLD"
    ct = e.enc(pt)
    print("PT:", pt)
    print("CT:", ct)

    # To decrypt: re-create machine with SAME settings + SAME start positions
    e2 = Enigma(rotor_names=("I","II","III"), reflector="B",
                positions="AAA", rings=(1,1,1), plug_pairs=plug)
    rt = e2.enc(ct)
    print("RT:", rt)

