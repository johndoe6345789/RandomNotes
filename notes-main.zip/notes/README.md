# notes

